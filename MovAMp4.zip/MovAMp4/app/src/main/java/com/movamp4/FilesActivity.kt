package com.movamp4

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.BaseColumns
import android.provider.MediaStore
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FilesActivity : Activity() {
    private val checks = mutableListOf<Pair<CheckBox, Uri>>()
    private lateinit var lista: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#12121A")); addView(col) })
        col.addView(TextView(this).apply { text = "📁 Mis archivos"; textSize = 28f; setTextColor(Color.WHITE) })
        agregar(col, boton("☑️  Seleccionar todo", Color.parseColor("#2979FF")) { checks.forEach { it.first.isChecked = true } })
        agregar(col, boton("🗑  Borrar seleccionados", Color.parseColor("#FF5252")) { confirmar() })
        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(lista)
        cargar()
    }

    private fun cargar() {
        lista.removeAllViews(); checks.clear()
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        for (base in listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)) {
            contentResolver.query(
                base,
                arrayOf(BaseColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED),
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%MOV a MP4%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val cb = CheckBox(this).apply {
                        text = "${c.getString(1)}\n" + String.format("%.1f MB", c.getLong(2) / 1048576.0) +
                            "  ·  " + fmt.format(Date(c.getLong(3) * 1000))
                        setTextColor(Color.WHITE); textSize = 15f
                    }
                    checks += cb to uri
                    agregar(lista, cb)
                }
            }
        }
        if (checks.isEmpty()) lista.addView(TextView(this).apply { text = "\nAún no hay archivos."; setTextColor(Color.parseColor("#9A9AB0")) })
    }

    private fun confirmar() {
        val sel = checks.filter { it.first.isChecked }
        if (sel.isEmpty()) { Toast.makeText(this, "No elegiste nada", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setMessage("¿Borrar ${sel.size} archivo(s)? No se puede deshacer.")
            .setPositiveButton("Borrar") { _, _ ->
                var ok = 0
                sel.forEach { try { if (contentResolver.delete(it.second, null, null) > 0) ok++ } catch (e: Exception) { } }
                Toast.makeText(this, "Borrados $ok de ${sel.size}", Toast.LENGTH_LONG).show()
                cargar()
            }.setNegativeButton("Cancelar", null).show()
    }
}
