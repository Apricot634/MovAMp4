package com.movamp4

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var bar: ProgressBar
    private lateinit var log: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        btn = Button(this).apply { text = "Elegir videos .MOV"; setOnClickListener { pick() } }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        log = TextView(this).apply { gravity = Gravity.START; textSize = 15f }
        root.addView(btn); root.addView(bar)
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { for (i in 0 until it.itemCount) uris += it.getItemAt(i).uri }
        data.data?.let { if (uris.isEmpty()) uris += it }
        btn.isEnabled = false; bar.max = uris.size; bar.progress = 0; log.text = ""
        Thread {
            var ok = 0
            uris.forEachIndexed { i, u ->
                val name = nameOf(u)
                val good = try { remux(u, name) } catch (e: Exception) { false }
                if (good) ok++
                runOnUiThread {
                    bar.progress = i + 1
                    log.append((if (good) "✅ " else "❌ ") + name + "\n")
                }
            }
            runOnUiThread {
                log.append("\nListo: $ok de ${uris.size} convertidos.\nGuardados en Movies/MOV a MP4\n")
                btn.isEnabled = true
            }
        }.start()
    }

    private fun nameOf(u: Uri): String =
        contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }?.substringBeforeLast('.') ?: "video_${System.currentTimeMillis()}"

    // Copia las pistas de video y audio SIN recodificar: cero pérdida de calidad.
    private fun remux(src: Uri, name: String): Boolean {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MOV a MP4")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, src, null)
            val rot = MediaMetadataRetriever().run {
                setDataSource(this@MainActivity, src)
                val r = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                release(); r
            }
            val pfd = contentResolver.openFileDescriptor(dest, "rw") ?: return false
            val mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    ex.selectTrack(i); map[i] = mux.addTrack(f)
                }
            }
            mux.setOrientationHint(rot)
            mux.start()
            val buf = ByteBuffer.allocate(8 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                info.set(0, size, ex.sampleTime, ex.sampleFlags)
                mux.writeSampleData(map[ex.sampleTrackIndex]!!, buf, info)
                ex.advance()
            }
            mux.stop(); mux.release(); pfd.close()
            contentResolver.update(dest, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            return true
        } catch (e: Exception) {
            contentResolver.delete(dest, null, null)
            return false
        } finally { ex.release() }
    }
}
