package com.movamp4

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import java.nio.ByteBuffer

fun Activity.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Activity.boton(t: String, c: Int, onClick: () -> Unit) = Button(this).apply {
    text = t; setTextColor(Color.WHITE); textSize = 17f; isAllCaps = false
    background = GradientDrawable().apply { setColor(c); cornerRadius = dp(18).toFloat() }
    setPadding(dp(16), dp(18), dp(16), dp(18)); setOnClickListener { onClick() }
}

fun Activity.agregar(col: LinearLayout, v: View) {
    col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
}

class MainActivity : Activity() {
    private lateinit var bar: ProgressBar
    private lateinit var log: TextView
    private lateinit var borrar: Switch
    private val botones = mutableListOf<Button>()
    private val buf by lazy { ByteBuffer.allocate(16 * 1024 * 1024) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#12121A")); addView(col) })
        col.addView(TextView(this).apply { text = "⚡ Creador Rápido"; textSize = 30f; setTextColor(Color.WHITE) })
        col.addView(TextView(this).apply { text = "Sin internet. Sin perder calidad."; setTextColor(Color.parseColor("#9A9AB0")) })
        botones += boton("🎬  Video → MP4 (4K, sin pérdida)", Color.parseColor("#7C4DFF")) { pick(1) }
        botones += boton("🎵  Extraer audio (sin pérdida)", Color.parseColor("#00B894")) { pick(2) }
        botones.forEach { agregar(col, it) }
        borrar = Switch(this).apply { text = "Borrar el original al terminar"; setTextColor(Color.WHITE); textSize = 16f }
        agregar(col, borrar)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        agregar(col, bar)
        log = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        col.addView(log)
        agregar(col, boton("📁  Mis archivos (ver y borrar)", Color.parseColor("#2979FF")) {
            startActivity(Intent(this, FilesActivity::class.java))
        })
        agregar(col, boton("🧹  Limpiar caché", Color.parseColor("#FF9100")) {
            cacheDir.deleteRecursively(); externalCacheDir?.deleteRecursively()
            Toast.makeText(this, "Caché limpia ✨", Toast.LENGTH_SHORT).show()
        })
    }

    private fun pick(req: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }, req)
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { for (i in 0 until it.itemCount) uris += it.getItemAt(i).uri }
        data.data?.let { if (uris.isEmpty()) uris += it }
        val solo = req == 2
        val del = borrar.isChecked
        botones.forEach { it.isEnabled = false }
        bar.max = uris.size; bar.progress = 0; log.text = ""
        Thread {
            var ok = 0
            uris.forEachIndexed { i, u ->
                val name = nameOf(u)
                val good = try { remux(u, name, solo) } catch (e: Exception) { false }
                var extra = ""
                if (good) {
                    ok++
                    if (del) extra = if (try { DocumentsContract.deleteDocument(contentResolver, u) } catch (e: Exception) { false })
                        "  🗑 original borrado" else "  ⚠️ no pude borrar el original"
                }
                runOnUiThread { bar.progress = i + 1; log.append((if (good) "✅ " else "❌ ") + name + extra + "\n") }
            }
            runOnUiThread {
                log.append("\nListo: $ok de ${uris.size}.\nGuardados en " + (if (solo) "Music" else "Movies") + "/MOV a MP4\n")
                botones.forEach { it.isEnabled = true }
            }
        }.start()
    }

    private fun nameOf(u: Uri): String =
        contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }?.substringBeforeLast('.') ?: "video_${System.currentTimeMillis()}"

    // Copia las pistas sin recodificar: misma calidad, 4K intacto, audio intacto.
    private fun remux(src: Uri, name: String, solo: Boolean): Boolean {
        val col = if (solo) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name + if (solo) ".m4a" else ".mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, if (solo) "audio/mp4" else "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (solo) "Music/MOV a MP4" else "Movies/MOV a MP4")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val dest = contentResolver.insert(col, v) ?: return false
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, src, null)
            var rot = 0
            if (!solo) rot = try {
                MediaMetadataRetriever().run {
                    setDataSource(this@MainActivity, src)
                    val r = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    release(); r
                }
            } catch (e: Exception) { 0 }
            contentResolver.openFileDescriptor(dest, "rw")!!.use { pfd ->
                val mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (m.startsWith("audio/") || (!solo && m.startsWith("video/"))) {
                        ex.selectTrack(i); map[i] = mux.addTrack(f)
                    }
                }
                if (map.isEmpty()) { mux.release(); throw IllegalStateException("sin pistas") }
                if (!solo) mux.setOrientationHint(rot)
                mux.start()
                val info = MediaCodec.BufferInfo()
                while (true) {
                    buf.clear()
                    val n = ex.readSampleData(buf, 0)
                    if (n < 0) break
                    info.set(0, n, ex.sampleTime, ex.sampleFlags)
                    mux.writeSampleData(map[ex.sampleTrackIndex]!!, buf, info)
                    ex.advance()
                }
                mux.stop(); mux.release()
            }
            contentResolver.update(dest, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            return true
        } catch (e: Exception) {
            contentResolver.delete(dest, null, null)
            return false
        } finally { ex.release() }
    }
}
